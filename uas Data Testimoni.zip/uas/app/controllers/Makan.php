<?php
class Makan extends Controller {

    public function __construct()
    {
        if($_SESSION['session_login'] != 'sudah_login') {
        Flasher::setMessage('Login','Tidak ditemukan.','danger');
        header('location: '. base_url . '/login');
        exit;
        }
    }
 
    public function index()
    {        
        $data['title']='Data Makanan';
        $data['makan']=$this->model('MakanModel')->getAllMakan();
        $this->view('templates/header', $data);
        $this->view('templates/sidebar', $data);
        $this->view('makan/index', $data);
        $this->view('templates/footer');
    }   

    public function cari()
    {
        $data['title'] = 'Data Makanan';
        $data['makan'] = $this->model('MakanModel')->cariMakan();
        $data['key'] = $_POST['key'];
        $this->view('templates/header', $data);
        $this->view('templates/sidebar', $data);
        $this->view('makan/index', $data);
        $this->view('templates/footer');
    }
    
    public function edit($id){
        $data['title'] = 'Detail Makan';
        $data['kategori'] = $this->model('KategoriModel')->getAllKategori();
        $data['makan'] = $this->model('MakanModel')->getMakanById($id);
        $this->view('templates/header', $data);
        $this->view('templates/sidebar', $data);
        $this->view('makan/edit', $data);
        $this->view('templates/footer');
    }

    public function tambah(){
            $data['title']= 'Tambah Makan';
            $data['kategori'] = $this->model('KategoriModel')->getAllKategori();
            $this->view('templates/header', $data);
            $this->view('templates/sidebar', $data);
            $this->view('makan/create', $data);
            $this->view('templates/footer');
    }

    public function simpanMakan(){
        if( $this->model('MakanModel')->tambahMakan($_POST) > 0) {
            Flasher::setMessage('Berhasil','ditambahkan','success');
            header('location: '. base_url . '/makan');
            exit;
        } else {
            Flasher::setMessage('Gagal','ditambahkah','danger');
            header('location: '. base_url . '/makan');
            exit;
        }
    }

    public function updateMakan(){
        if( $this->model('MakanModel')->updateDataMakan($_POST) > 0) {
            Flasher::setMessage('Berhasil','diupdate','success');
            header('location: '. base_url . '/makan');
            edit;
        }
    }

    public function hapus($id){
        if( $this->model('MakanModel')->deleteMakan($id) > 0){
            Flasher::setMessage('Berhasil','dihapus','success');
            header('location: '. base_url. '/makan');
            exit;
        } else{
            Flasher::setMessage('Gagal','dihapus','danger');
            header('location: '. base_url . '/makan');
            exit;
        }
    }

    public function lihatlaporan(){
        $data['title'] = 'Data Laporan Makan';
            $data['makan'] = $this->model('MakanModel')->getAllMakan();
        $this->view('makan/lihatlaporan', $data);
    }
}