<?php

class MakanModel 
{
        private $table = 'makan';
        private $db;

        public function __construct()
        {
            $this->db = new Database;
        }

        public function getAllMakan()
        {
            $this->db->query("SELECT makan.*, kategori.nama_kategori FROM " . $this->table. " JOIN kategori ON
                kategori.id = makan.kategori_id");
            return $this->db->resultSet();
        }

        public function getMakanById($id)
        {
                $this->db->query('SELECT * FROM ' . $this->table . ' WHERE id=:id');
                $this->db->bind('id',$id);
                return $this->db->single();
        }

        public function tambahMakan($data)
        {
            $query = "INSERT INTO makan (nama, daerah, rasa, kategori_id, harga) VALUES(:nama, :daerah, :rasa, :kategori_id, :harga)";
            $this->db->query($query);
            $this->db->bind('nama', $data['nama']);
            $this->db->bind('daerah', $data['daerah']);
            $this->db->bind('rasa', $data['rasa']);
            $this->db->bind('kategori_id', $data['kategori_id']);
            $this->db->bind('harga', $data['harga']);
            $this->db->execute();

            return $this->db->rowCount();
        }

        public function updateDataMakan($data)
        {
            $query = "UPDATE makan SET nama=:nama, daerah=:daerah, rasa=:rasa, kategori_id=:kategori_id, harga=:harga WHERE id=:id";
            $this->db->query($query);
            $this->db->bind('nama', $data['nama']);
            $this->db->bind('daerah', $data['daerah']);
            $this->db->bind('rasa', $data['rasa']);
            $this->db->bind('kategori_id', $data['kategori_id']);
            $this->db->bind('harga', $data['harga']);
            $this->db->execute();

            return $this->db->rowCount();
        }

        public function deleteMakan($id)
        {
            $this->db->query('DELETE FROM ' . $this->table . ' WHERE id=:id');
            $this->db->bind('id',$id);
            $this->db->execute();

            return $this->db->rowCount();
        }

        public function cariMakan()
        {
            $key = $_POST['key'];
            $this->db->query("SELECT * FROM " . $this->table . " WHERE nama LIKE :key");
            $this->db->bind('key',"%$key%");
            return $this->db->resultSet();
        }
}